// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xseqmatcherhw.h"

extern XSeqmatcherhw_Config XSeqmatcherhw_ConfigTable[];

XSeqmatcherhw_Config *XSeqmatcherhw_LookupConfig(u16 DeviceId) {
	XSeqmatcherhw_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XSEQMATCHERHW_NUM_INSTANCES; Index++) {
		if (XSeqmatcherhw_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XSeqmatcherhw_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSeqmatcherhw_Initialize(XSeqmatcherhw *InstancePtr, u16 DeviceId) {
	XSeqmatcherhw_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSeqmatcherhw_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSeqmatcherhw_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

